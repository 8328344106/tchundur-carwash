import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Locations } from '../locations';
import { ShedulingServService } from '../sheduling-serv.service';
import { AddLocationDetailsComponent } from '../add-location-details/add-location-details.component';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-edit-customer-location',
  templateUrl: './edit-customer-location.component.html',
  styleUrls: ['./edit-customer-location.component.css']
})
export class EditCustomerLocationComponent implements OnInit {

  regForm: FormGroup;
  locmodel: Locations = new Locations();
  constructor(private fb: FormBuilder, 
             private locservice:ShedulingServService,
              private dialogref:MatDialogRef<AddLocationDetailsComponent>) { }

  ngOnInit(): void 
  {
      this.getlocationbyid();
      this.regForm = this.fb.group({
      doornumber: ['', [Validators.required ]],
      street:['',[ Validators.required] ],
      landmark: ['', [Validators.required ]],
      city:['',[ Validators.required] ],
      dist:['',[ Validators.required] ],
      state: ['', [Validators.required ]],
      pincode:['',[ Validators.required] ]
    });
    
  }

  getlocationbyid()
  {
    const editlocid = localStorage.getItem('editlocid');
    localStorage.removeItem('editlocid');
    this.locservice.getlocationbyid(editlocid).subscribe( data =>
      {
        this.locmodel = data;
      })
  }

  onLocation()
  {
      this.locmodel.username = localStorage.getItem('username');
      this.locservice.addlocations(this.locmodel).subscribe( data =>
        {
          if(data != null)
          {
            this.dialogref.close();
          }
        });
  }

  onclose()
  {
    this.dialogref.close();
  }


}
