import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Carmodel } from '../carmodel';
import { Router } from '@angular/router';
import { ShedulingServService } from '../sheduling-serv.service';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-edit-customer-car',
  templateUrl: './edit-customer-car.component.html',
  styleUrls: ['./edit-customer-car.component.css']
})
export class EditCustomerCarComponent implements OnInit {

  regForm: FormGroup;
  carmodel: Carmodel= new Carmodel();
  constructor(private fb: FormBuilder,
              private route: Router,
              private carshed: ShedulingServService,
              private dialogref:MatDialogRef<EditCustomerCarComponent>) { }

  ngOnInit(): void 
  {
    this.getcarbyid();
    this.regForm = this.fb.group({
      brand: ['', [Validators.required ]],
      color:['',[ Validators.required] ],
      cartype:['',[ Validators.required] ],
      imagefile:['',[ Validators.required] ]
    });
  }

  getcarbyid()
  {
    const editcarid = localStorage.getItem('editcarid');
    localStorage.removeItem('editcarid');
    this.carshed.getcarbyid(editcarid).subscribe(data =>
      {
        this.carmodel = data;
      })
  }

  selectedFiles: FileList;
  currentFileUpload: File;
  onSelectFile(event)
  {
    this.selectedFiles = event.target.files;
  }
  onEdit()
  {
    this.carmodel.username= localStorage.getItem('username');
    this.currentFileUpload = this.selectedFiles.item(0);
    this.carshed.addCardetails(this.carmodel,this.currentFileUpload)
    .subscribe((data) =>{
      localStorage.removeItem('editid');
      this.dialogref.close();
     })

  }
onclose(){
  this.dialogref.close();
}
}

