import { Component, OnInit } from '@angular/core';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { Carmodel } from '../carmodel';
import { Router } from '@angular/router';
import { ShedulingServService } from '../sheduling-serv.service';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-add-car-details',
  templateUrl: './add-car-details.component.html',
  styleUrls: ['./add-car-details.component.css']
})
export class AddCarDetailsComponent implements OnInit {

  regForm: FormGroup;
  carmodel: Carmodel= new Carmodel();
  constructor(private fb: FormBuilder,
              private route: Router,
              private carshed: ShedulingServService,
              private dialogref:MatDialogRef<AddCarDetailsComponent>) { }

  ngOnInit(): void 
  {
    this.regForm = this.fb.group({
      brand: ['', [Validators.required ]],
      color:['',[ Validators.required] ],
      cartype:['',[ Validators.required] ],
      imagefile:['',[ Validators.required] ]
    });
  }

  selectedFiles: FileList;
  currentFileUpload: File;
  onSelectFile(event)
  {
    this.selectedFiles = event.target.files;
  }
  onAdd()
  {
    this.carmodel.username= localStorage.getItem('username');
    this.currentFileUpload = this.selectedFiles.item(0);
    this.carshed.addCardetails(this.carmodel,this.currentFileUpload)
    .subscribe((data) =>{
      this.dialogref.close();
     })

  }
onclose(){
  this.dialogref.close();
}
}