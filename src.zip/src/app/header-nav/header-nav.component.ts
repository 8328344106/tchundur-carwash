import { Component, ChangeDetectorRef } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header-nav',
  templateUrl: './header-nav.component.html',
  styleUrls: ['./header-nav.component.css']
})
export class HeaderNavComponent {

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );
    constructor(private breakpointObserver: BreakpointObserver,
      iconRegistry: MatIconRegistry,private changeDetector:ChangeDetectorRef, 
      sanitizer: DomSanitizer,
      private route:Router) {
      iconRegistry.addSvgIcon(
          'menu',
          sanitizer.bypassSecurityTrustResourceUrl('assets/menu.svg'));
        
        iconRegistry.addSvgIcon(
          'account',
          sanitizer.bypassSecurityTrustResourceUrl('assets/account.svg'));

          iconRegistry.addSvgIcon(
            'signup',
            sanitizer.bypassSecurityTrustResourceUrl('assets/signup.svg'));

          iconRegistry.addSvgIcon(
            'login',
            sanitizer.bypassSecurityTrustResourceUrl('assets/login.svg'));

          iconRegistry.addSvgIcon(
              'add',
              sanitizer.bypassSecurityTrustResourceUrl('assets/add.svg'));
          iconRegistry.addSvgIcon(
                'delete',
            sanitizer.bypassSecurityTrustResourceUrl('assets/delete.svg'));
          iconRegistry.addSvgIcon(
              'close',
          sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
          iconRegistry.addSvgIcon(
            'edit',
        sanitizer.bypassSecurityTrustResourceUrl('assets/edit.svg'));
        iconRegistry.addSvgIcon(
          'select',
          sanitizer.bypassSecurityTrustResourceUrl('assets/select.svg'));
          iconRegistry.addSvgIcon(
            'cart',
            sanitizer.bypassSecurityTrustResourceUrl('assets/cart.svg'));
            iconRegistry.addSvgIcon(
              'verified',
            sanitizer.bypassSecurityTrustResourceUrl('assets/verified.svg'));
            iconRegistry.addSvgIcon(
              'track',
            sanitizer.bypassSecurityTrustResourceUrl('assets/track.svg'));
        }

        read()
        {
          return localStorage.getItem('role');
        }
        logout()
        {
          localStorage.setItem('afterlogin',"false");
          //localStorage.setItem('username',' ');
          localStorage.removeItem('role');
          localStorage.removeItem('shedid');
         // this.authservice.logout();
         this.route.navigateByUrl('login');
         
        }

        readvalues()
        {
            return localStorage.getItem('afterlogin');
        }
       
        cart()
        {
          this.route.navigateByUrl('cart');
        }
        cus()
        {
          let cus ="customer";
          return cus;
        }
       
}
