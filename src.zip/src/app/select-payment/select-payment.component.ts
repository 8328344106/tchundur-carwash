import { Component, OnInit } from '@angular/core';
import { Payment } from '../payment';
import { CustomerservService } from '../customerserv.service';
import { ShedulingServService } from '../sheduling-serv.service';
import { ActivatedRoute, Router} from '@angular/Router';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { AddPaymentDetailsComponent } from '../add-payment-details/add-payment-details.component';
import { EditCustomerPaymentComponent } from '../edit-customer-payment/edit-customer-payment.component';
import { Customershedule } from '../customershedule';
import { BookingSuccessfulComponent } from '../booking-successful/booking-successful.component';

@Component({
  selector: 'app-select-payment',
  templateUrl: './select-payment.component.html',
  styleUrls: ['./select-payment.component.css']
})
export class SelectPaymentComponent implements OnInit {

  submitted: boolean = false;
  id: string;
  select= "false";
  paymodel: Payment[];
  constructor(private route: Router,
              private activeroute: ActivatedRoute,
              private curser: CustomerservService,
              private carshed: ShedulingServService,
              private dialog:MatDialog) { }

  ngOnInit(): void 
  {
    this.getpaymentbyuser();   
    this.getpayid();
  }

  getpayid()
  {
    if(localStorage.getItem('payid') == null)
    {

    }
    else
    {
      this.id = localStorage.getItem('payid');
      this.select="true";
    }
  }

  getpaymentbyuser()
  {
    this.carshed.getpaymentbyuser().subscribe(data=>
      {
        this.paymodel= data as Payment[];
      });
  }
  
  onselect(loc)
  {
    this.id = loc.id;
    localStorage.setItem('payid',loc.id);
    this.select = "true";
  }

  onCancel()
  {
    localStorage.removeItem('payid');
    this.route.navigateByUrl('cart');
  }

  onPrevious()
  {
    this.route.navigateByUrl('cart');
  }

  onNext()
  {
    this.route.navigateByUrl('success');
  }

  onAdd()
  {
    const dialogconfig =  new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus= true;
    this.dialog.afterAllClosed.subscribe(data => {
      this.getpaymentbyuser();
    });
    this.dialog.open(AddPaymentDetailsComponent,dialogconfig);
  }

  onEdit(edit)
  {
    localStorage.setItem('editpayid',edit)
    const dialogconfig =  new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus= true;
    this.dialog.afterAllClosed.subscribe(data => {
      this.getpaymentbyuser();
    });
    this.dialog.open(EditCustomerPaymentComponent,dialogconfig);
  }
  ondelete( pay)
  {
    var r = confirm("Confirm to delete the payment details!");
    if(r == true)
    {
      if(this.id == pay)
      {
        localStorage.removeItem('payid');
        this.id = null;
        this.select = "false";
      }
      this.carshed.deletepay(pay).subscribe(data =>
      {
        this.getpaymentbyuser();
        this.getpayid();
        
      });
      this.curser.afterdelete();
    }
    
  }

}
