import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WasherHistoryComponent } from './washer-history.component';

describe('WasherHistoryComponent', () => {
  let component: WasherHistoryComponent;
  let fixture: ComponentFixture<WasherHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WasherHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WasherHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
