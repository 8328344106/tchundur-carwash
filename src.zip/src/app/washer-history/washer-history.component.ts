import { Component, OnInit } from '@angular/core';
import { NgForm, FormGroup, FormBuilder } from '@angular/forms';
import { Customershedule } from '../customershedule';
import { Register } from '../register';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { CustomerservService } from '../customerserv.service';
import { ShedulingServService } from '../sheduling-serv.service';
import * as moment from 'moment';
import { AssignWasherComponent } from '../assign-washer/assign-washer.component';

@Component({
  selector: 'app-washer-history',
  templateUrl: './washer-history.component.html',
  styleUrls: ['./washer-history.component.css']
})
export class WasherHistoryComponent implements OnInit {

  shedule: Customershedule[];
  track : Customershedule;
  check:boolean = false;
  regForm:FormGroup;
  carimage: any;
  rate: boolean;
  washername: any;
  serviceimage: any;
  base64Data: any;
  washer: Register[];
  public todate = new Date();
  constructor(private route:Router,
              private fb: FormBuilder,
              private dialog:MatDialog,
              private cusser: CustomerservService,
              private shedser: ShedulingServService) { }

  ngOnInit(): void 
  {
    this.getshedafterorder();
    if(localStorage.getItem('shedid') == null)
    {
      this.check = false;
    }
    else
    {
      this.gettrackbyid();
      this.check = true;
      
    }
  }

  getshedafterorder()
  {
    this.shedser.getshedwashbyuser().subscribe( data => {
      this.shedule = data;
        
    })
  }

  gettrackbyid()
  {
    this.shedser.getshedbyid().subscribe( data =>{
        this.track = data;
      this.serviceimage=this.track.servicedetails.image;
      this.base64Data=this.serviceimage;
      this.serviceimage ='data:image/jpeg;Base64,'+this.base64Data;
      this.carimage = this.track.cardetails.image;
      this.base64Data=this.carimage
      this.carimage ='data:image/jpeg;Base64,'+this.base64Data;
      if(this.track.rating == null)
      {
        this.rate = true;
      }
      else
      {
        this.rate = false;
      }
      
    })
  }

  onUpdatestatus(data)
  {
    this.track.status = data;
    this.shedser.addshedule(this.track).subscribe(data =>{
      this.track = data;
      this.cusser.afterdelete();
    })
  }

  onTrack(id)
  {
    localStorage.setItem('shedid',id);
    this.gettrackbyid();
    this.check = true;
  }

  
  onclose()
  {
    this.check = false;
    localStorage.removeItem('shedid');
    
  }
}

