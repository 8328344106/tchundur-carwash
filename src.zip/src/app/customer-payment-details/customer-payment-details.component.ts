import { Component, OnInit } from '@angular/core';
import { MatDialogConfig, MatDialog } from '@angular/material/dialog';
import { AddPaymentDetailsComponent } from '../add-payment-details/add-payment-details.component';
import { Router } from '@angular/router';
import { ShedulingServService } from '../sheduling-serv.service';
import { Payment } from '../payment';
import { CustomerservService } from '../customerserv.service';
import { EditCustomerPaymentComponent } from '../edit-customer-payment/edit-customer-payment.component';

@Component({
  selector: 'app-customer-payment-details',
  templateUrl: './customer-payment-details.component.html',
  styleUrls: ['./customer-payment-details.component.css']
})
export class CustomerPaymentDetailsComponent implements OnInit {

  id: string;
  select= "false";
  paymodel: Payment[];
  constructor(private route: Router,
              private curser: CustomerservService,
              private carshed: ShedulingServService,
              private dialog:MatDialog) { }

  ngOnInit(): void 
  {
    
    this.getpaymentbyuser();   
  
  }

  getpaymentbyuser()
  {
    this.carshed.getpaymentbyuser().subscribe(data=>
      {
        this.paymodel= data as Payment[];
      });
  }
  
  onAdd()
  {
    const dialogconfig =  new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus= true;
    this.dialog.afterAllClosed.subscribe(data => {
      this.getpaymentbyuser();
    });
    this.dialog.open(AddPaymentDetailsComponent,dialogconfig);
  }

  onEdit(edit)
  {
    localStorage.setItem('editpayid',edit)
    const dialogconfig =  new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus= true;
    this.dialog.afterAllClosed.subscribe(data => {
      this.getpaymentbyuser();
    });
    this.dialog.open(EditCustomerPaymentComponent,dialogconfig);
  }
  ondelete( pay)
  {
    var r = confirm("Confirm to delete the payment details!");
    if(r == true)
    {
    
      this.carshed.deletepay(pay).subscribe(data =>
      {
        this.getpaymentbyuser();
        
      });
      this.curser.afterdelete();
    }
    
  }

}

