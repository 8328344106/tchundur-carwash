export class Register
{
    id : string;
	username : string;
	firstname: string;
	lastname: string;
	email : string;
	mobilenumber : number;
	password : string;
	role : string;
}