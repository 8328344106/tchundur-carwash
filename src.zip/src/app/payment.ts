export class Payment
{
    id: String;
	username: String;
	cardholdername: String;
	cardnumber: number;
	expmon: String;
	expyear: Number;
	cvv: Number;

}