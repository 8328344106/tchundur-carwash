import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { CustomerservService } from '../customerserv.service';
import { MatDialogConfig, MatDialog } from '@angular/material/dialog';
import { EditWasherDetailsComponent } from '../edit-washer-details/edit-washer-details.component';
import { Register } from '../register';
import { AddWasherDetailsComponent } from '../add-washer-details/add-washer-details.component';

@Component({
  selector: 'app-washer-details',
  templateUrl: './washer-details.component.html',
  styleUrls: ['./washer-details.component.css']
})
export class WasherDetailsComponent implements OnInit {

  displayedColumns: string[] = ['username','firstname','lastname', 'email', 'mobilenumber','edit','delete'];
  dataSource = new MatTableDataSource();
  model: Register = new Register();
  role: string;


  constructor(private route: Router,
              private cusser: CustomerservService,
              private dialog:MatDialog) 
  { 

  }

  ngOnInit(): void 
  {
    this.getwasherdetails();
  
  }
  
  getwasherdetails()
  {
    this.role="washer";
    this.cusser.getbyrole(this.role).subscribe(res=>
    {
        this.dataSource.data=res;
  
    });
  }
  onEdit(element)
  {
    localStorage.setItem('id',element);
    const dialogconfig =  new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus= true;
    this.dialog.afterAllClosed.subscribe(data => {
      this.getwasherdetails();
    });
    this.dialog.open(EditWasherDetailsComponent,dialogconfig);
  }

  onAdd()
  {
    const dialogconfig =  new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus= true;
    this.dialog.afterAllClosed.subscribe(data => {
      this.getwasherdetails();
    });
    this.dialog.open(AddWasherDetailsComponent,dialogconfig);
  }
  onDelete(element)
  {
    var r = confirm("Confirm delete washer");
    if(r == true)
    {
    this.cusser.deleteuser(element).subscribe(
      res =>
      {
        if(res == true)
        {
            this.getwasherdetails();
        }
      })
      this.cusser.afterdelete(); 

    }
  }
}
