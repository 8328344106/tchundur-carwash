import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditWasherDetailsComponent } from './edit-washer-details.component';

describe('EditWasherDetailsComponent', () => {
  let component: EditWasherDetailsComponent;
  let fixture: ComponentFixture<EditWasherDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditWasherDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditWasherDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
