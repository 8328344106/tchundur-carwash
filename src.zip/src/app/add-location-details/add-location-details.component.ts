import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { ShedulingServService } from '../sheduling-serv.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Locations } from '../locations';

@Component({
  selector: 'app-add-location-details',
  templateUrl: './add-location-details.component.html',
  styleUrls: ['./add-location-details.component.css']
})
export class AddLocationDetailsComponent implements OnInit {

  regForm: FormGroup;
  locmodel: Locations = new Locations();
  constructor(private fb: FormBuilder, 
             private locservice:ShedulingServService,
              private dialogref:MatDialogRef<AddLocationDetailsComponent>) { }

  ngOnInit(): void 
  {
    this.regForm = this.fb.group({
      doornumber: ['', [Validators.required ]],
      street:['',[ Validators.required] ],
      landmark: ['', [Validators.required ]],
      city:['',[ Validators.required] ],
      dist:['',[ Validators.required] ],
      state: ['', [Validators.required ]],
      pincode:['',[ Validators.required] ]
    });
    
  }

  onLocation()
  {
      this.locmodel.username = localStorage.getItem('username');
      this.locservice.addlocations(this.locmodel).subscribe( data =>
        {
          if(data != null)
          {
            this.dialogref.close();
          }
        });
  }

  onclose()
  {
    this.dialogref.close();
  }

}
