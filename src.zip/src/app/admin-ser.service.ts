import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { WashService } from './washservice';
import { catchError, tap, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AdminSerService {

  private AdminUrl = 'http://localhost:8888/caradmin/service';
  constructor(private http: HttpClient) 
  { 

  }

  getservicedetails() : Observable<WashService[]>
  {
    return this.http.get<WashService[]>(`${this.AdminUrl}`+`/getservices`);
  }

  getperticularservice(): Observable<WashService>
  {
    const id = localStorage.getItem('servid');
    return this.getservicedetails()
    .pipe(
      map((packs: WashService[]) => packs.find(items => items.id == id))
    );
  }
  
  deleteservice(id) : Observable<any>
  {
    return this.http.delete<any>(`${this.AdminUrl}`+`/deleteservice/`+`${id}`);
  }

  addServdetails(wash : WashService,files: File): Observable<WashService>
  {
    const formdata: FormData = new FormData();
    formdata.append('wash', JSON.stringify(wash));
    formdata.append('file', files);
    return this.http.post<WashService>(`${this.AdminUrl}`+`/addservices`,formdata);
  }
  
}
