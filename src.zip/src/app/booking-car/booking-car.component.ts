import {
  Component,
  OnInit
} from '@angular/core';
import {
  AddCarDetailsComponent
} from '../add-car-details/add-car-details.component';
import {
  MatDialogConfig,
  MatDialog
} from '@angular/material/dialog';
import {
  Carmodel
} from '../carmodel';
import {
  Router
} from '@angular/router';
import {
  ShedulingServService
} from '../sheduling-serv.service';
import {
  CustomerservService
} from '../customerserv.service';
import {
  EditCustomerCarComponent
} from '../edit-customer-car/edit-customer-car.component';

@Component({
  selector: 'app-booking-car',
  templateUrl: './booking-car.component.html',
  styleUrls: ['./booking-car.component.css']
})
export class BookingCarComponent implements OnInit {

  select = "false";
  base64Data: any;
  image: any;
  carmodel: Carmodel[];
  id: String;
  images: any;
  c: Carmodel;
  constructor(private route: Router,
    private carshed: ShedulingServService,
    private curser: CustomerservService,
    private dialog: MatDialog) {

  }

  ngOnInit(): void {
    this.getcarbyuser();
    if (localStorage.getItem('carid') == null) {

    } else {
      this.id = localStorage.getItem('carid');
      this.select = "true";
    }
  }

  onSelect(car) {
    this.id = car.id;
    localStorage.setItem('carid', car.id);
    this.select = "true";
  }

  onNext() {
    this.route.navigateByUrl('shedulenow');
  }

  onCancel() {
    localStorage.removeItem('servid');
    localStorage.removeItem('locid');
    localStorage.removeItem('carid');
    localStorage.removeItem('payid');
    this.route.navigateByUrl('home');
  }

  onPrevious() {
    this.route.navigateByUrl('booklocation');
  }

  getcarbyuser() {
    this.carshed.getcarbyuser().subscribe(data => {
      this.carmodel = data as Carmodel[];

      for (let d in this.carmodel) {
        //console.log(d);
        this.image = this.carmodel[d];
        this.base64Data = this.image.image;
        this.carmodel[d].image = 'data:image/jpeg;Base64,' + this.base64Data;
      }

    });
  }
  onAdd() {
    const dialogconfig = new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus = true;
    this.dialog.afterAllClosed.subscribe(data => {
      this.getcarbyuser();
    });
    this.dialog.open(AddCarDetailsComponent, dialogconfig);
  }

  onEdit(car) {
    localStorage.setItem('editcarid', car);
    const dialogconfig = new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus = true;
    this.dialog.afterAllClosed.subscribe(data => {
      this.getcarbyuser();
    });
    this.dialog.open(EditCustomerCarComponent, dialogconfig);
  }
  onDelete(car) {
    var r = confirm("confirm delete your car details!")
    if (r == true) 
    {
      if(this.id == car )
      {
        localStorage.removeItem('carid');
        this.id = null;
        this.select = "false";
      }
      this.carshed.deletecar(car).subscribe(data => {
        this.getcarbyuser();
      })
      this.curser.afterdelete();
    }
  }

}
