import { WashService } from './washservice';
import { Carmodel } from './carmodel';
import { Locations } from './locations';
import { Payment } from './payment';

export class Customershedule
{
    id: string;
    username: string;
    washername: string;
    servicedetails: WashService;
    cardetails: Carmodel;
    locationdetails: Locations;
    paymentdetails: Payment;
    bookeddate: string;
    sheduledate: string;
    sheduletime: string;
    washeraccepteddate: string;
    servicetax:number;
    totalamount:number;
    transactionid: number;
    bookingid: number;
    status: string;
    rating: number;
    review: string;
}