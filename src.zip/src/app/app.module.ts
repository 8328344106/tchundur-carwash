import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CustomerRegisterComponent } from './customer-register/customer-register.component';
import { HeaderNavComponent } from './header-nav/header-nav.component';
import { LayoutModule } from '@angular/cdk/layout';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {HttpClientModule} from '@angular/common/http';
import { CustomerLoginComponent } from './customer-login/customer-login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HomeComponent } from './home/home.component';
import { CarouselModule } from 'ngx-bootstrap/carousel';
import { CustomercardetailsComponent } from './customercardetails/customercardetails.component';
import { CustomerPaymentDetailsComponent } from './customer-payment-details/customer-payment-details.component';
import { WasherHistoryComponent } from './washer-history/washer-history.component';
import { AddCarDetailsComponent } from './add-car-details/add-car-details.component';
import { MatDialogModule } from '@angular/material/dialog';
import { SheduleNowComponent } from './shedule-now/shedule-now.component';
import { AddPaymentDetailsComponent } from './add-payment-details/add-payment-details.component';
import { WasherDetailsComponent } from './washer-details/washer-details.component';
import { AddWasherDetailsComponent } from './add-washer-details/add-washer-details.component';
import { WashingServicesComponent } from './washing-services/washing-services.component';
import { AddWashingServicesComponent } from './add-washing-services/add-washing-services.component';
import { AddAdminDetailsComponent } from './add-admin-details/add-admin-details.component';
import { MatTableModule } from '@angular/material/table';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { EditWasherDetailsComponent } from './edit-washer-details/edit-washer-details.component';
import { CustomerDetailsComponent } from './customer-details/customer-details.component';
import { EditCustomerDetailsComponent } from './edit-customer-details/edit-customer-details.component';
import { EditWashingServiceComponent } from './edit-washing-service/edit-washing-service.component';
import { AddLocationDetailsComponent } from './add-location-details/add-location-details.component';
import { LocationDetailsComponent } from './location-details/location-details.component';
import { EditCustomerLocationComponent } from './edit-customer-location/edit-customer-location.component';
import { BookingCarComponent } from './booking-car/booking-car.component';
import { BookingLocationComponent } from './booking-location/booking-location.component';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatNativeDateModule } from '@angular/material/core';
import { MatInputModule } from '@angular/material/input';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { SelectPaymentComponent } from './select-payment/select-payment.component';
import { EditCustomerPaymentComponent } from './edit-customer-payment/edit-customer-payment.component';
import { EditCustomerCarComponent } from './edit-customer-car/edit-customer-car.component';
import { BookingSuccessfulComponent } from './booking-successful/booking-successful.component';
import { CartComponent } from './cart/cart.component';
import { YourOrdersComponent } from './your-orders/your-orders.component';
import { AdminDetailsComponent } from './admin-details/admin-details.component';
import { EditAdminDetailsComponent } from './edit-admin-details/edit-admin-details.component';
import { CustomerWashRequestsComponent } from './customer-wash-requests/customer-wash-requests.component';
import { AssignWasherComponent } from './assign-washer/assign-washer.component';
import {MatSelectModule} from '@angular/material/select';

@NgModule({
  declarations: [
    AppComponent,
    CustomerRegisterComponent,
    HeaderNavComponent,
    CustomerLoginComponent,
    HomeComponent,
    CustomercardetailsComponent,
    CustomerPaymentDetailsComponent,
    WasherHistoryComponent,
    AddCarDetailsComponent,
    SheduleNowComponent,
    AddPaymentDetailsComponent,
    WasherDetailsComponent,
    AddWasherDetailsComponent,
    WashingServicesComponent,
    AddWashingServicesComponent,
    AddAdminDetailsComponent,
    EditWasherDetailsComponent,
    CustomerDetailsComponent,
    EditCustomerDetailsComponent,
    EditWashingServiceComponent,
    AddLocationDetailsComponent,
    LocationDetailsComponent,
    EditCustomerLocationComponent,
    BookingCarComponent,
    BookingLocationComponent,
    SelectPaymentComponent,
    EditCustomerPaymentComponent,
    EditCustomerCarComponent,
    BookingSuccessfulComponent,
    CartComponent,
    YourOrdersComponent,
    AdminDetailsComponent,
    EditAdminDetailsComponent,
    CustomerWashRequestsComponent,
    AssignWasherComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule,
    LayoutModule,
    MatDialogModule,
    MatDatepickerModule,
    MatInputModule,
    MatToolbarModule,
    MatSelectModule,
    MatButtonModule,
    MatSidenavModule,
    MatNativeDateModule,
    MatFormFieldModule,
    MatIconModule,
    MatListModule,
    MatTableModule,
    MatMenuModule,
    MatCheckboxModule,
    BrowserAnimationsModule,
    CarouselModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
