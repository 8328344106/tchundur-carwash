import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddWashingServicesComponent } from './add-washing-services.component';

describe('AddWashingServicesComponent', () => {
  let component: AddWashingServicesComponent;
  let fixture: ComponentFixture<AddWashingServicesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddWashingServicesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddWashingServicesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
