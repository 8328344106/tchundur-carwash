import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { WashService } from '../washservice';
import { Router } from '@angular/router';
import { AdminSerService } from '../admin-ser.service';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-add-washing-services',
  templateUrl: './add-washing-services.component.html',
  styleUrls: ['./add-washing-services.component.css']
})
export class AddWashingServicesComponent implements OnInit {

  regForm: FormGroup;
  submitted: boolean = false;
  servmodel: WashService=new WashService();
  constructor(private fb: FormBuilder,
              private route: Router,
              private admser: AdminSerService,
              private dialogref:MatDialogRef<AddWashingServicesComponent>) { }

  ngOnInit(): void 
  {
    this.regForm = this.fb.group({
      servicename: ['', [Validators.required ]],
      description:['',[ Validators.required] ],
      amount:['',[ Validators.required] ],
      imagefile:['',[ Validators.required] ]
    });
  }

  selectedFiles: FileList;
  currentFileUpload: File;
  onSelectFile(event)
  {
    this.selectedFiles = event.target.files;
  }
  onAdd()
  {
    this.currentFileUpload = this.selectedFiles.item(0);
    this.admser.addServdetails(this.servmodel,this.currentFileUpload)
    .subscribe((data) =>
    {
      this.dialogref.close();
      
    })

  }
onclose()
{
  this.dialogref.close();
}

}
