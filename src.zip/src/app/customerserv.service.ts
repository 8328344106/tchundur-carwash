import { Injectable, Output, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError, tap, map } from'rxjs/operators';


import { Register } from './register';

@Injectable({
  providedIn: 'root'
})

export class CustomerservService 
{

  private RegisterUrl = 'http://localhost:8888/customerregister/customer';
  constructor(private http: HttpClient) 
  { 

  }
  @Output() getLoggedInName: EventEmitter<any> = new EventEmitter();
 
  addcustomer( register: Register): Observable<Register>
  {
      return this.http.post<Register>(`${this.RegisterUrl}`+`/register`,register);
  }

  getcustomer(): Observable<Register[]>
  {
    return this.http.get<Register[]>(`${this.RegisterUrl}`+`/getcustomer`);
  }

  customerlogin(login: Object): Observable<Object>
  {
    return this.http.post<Object>(`${this.RegisterUrl}`+`/login`,login);
  }

  getbyrole(role: string): Observable<Register[]>
  {
    return this.getcustomer()
    .pipe(
      map((cus: Register[]) => cus.filter(items => items.role == role))
    );
  }

  deleteuser(id: string) :Observable<any>
  {
    return this.http.delete<any>(`${this.RegisterUrl}`+`/deleteuser/`+`${id}`);
  }
  
  afterdelete()
  {
    this.getLoggedInName.emit();
  }

  getperticularuser() : Observable<Register>
  {
    const id = localStorage.getItem('id');
    return this.getcustomer()
    .pipe(
      map((cus: Register[]) => cus.find(items => items.id == id))
    );
  }

}