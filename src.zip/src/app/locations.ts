export class Locations
{
    id: string;
	username: string;
	doornumber: string;
    street: string;
    landmark: string;
    city: string;
	dist: string;
	state: string;
	pincode: string;
}