export class WashService
{
    id: string;
    servicename: string;
	description: string;
	image: string;
	imagename:string;
	amount: number;

}