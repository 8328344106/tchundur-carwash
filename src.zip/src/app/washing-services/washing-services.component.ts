import { Component, OnInit } from '@angular/core';
import { MatDialogConfig, MatDialog } from '@angular/material/dialog';
import { AddWashingServicesComponent } from '../add-washing-services/add-washing-services.component';
import { Router } from '@angular/router';
import { WashService } from '../washservice';
import { AdminSerService } from '../admin-ser.service';
import { CustomerservService } from '../customerserv.service';
import { EditWashingServiceComponent } from '../edit-washing-service/edit-washing-service.component';

@Component({
  selector: 'app-washing-services',
  templateUrl: './washing-services.component.html',
  styleUrls: ['./washing-services.component.css']
})
export class WashingServicesComponent implements OnInit {
  

  servmodel: WashService[];
  submitted: boolean = false;
  base64Data: any;
  image:any;
  constructor(private route: Router,
              private washser: AdminSerService,
              private curser: CustomerservService,
              private dialog:MatDialog) { }

  ngOnInit(): void 
  {
      localStorage.removeItem('booknow');
      this.getservicedetails();
  }

  getservicedetails()
  {
    this.washser.getservicedetails().subscribe(data=>
      {
        this.servmodel= data as WashService[];

        for(let d in this.servmodel)
        {
          //console.log(d);
          this.image=this.servmodel[d];
          this.base64Data=this.image.image;
          this.servmodel[d].image ='data:image/jpeg;Base64,'+this.base64Data;
        }
        
      });
  }

  onEdit(serv)
  {
    localStorage.setItem('servid',serv);
    const dialogconfig =  new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus= true;
    this.dialog.afterAllClosed.subscribe(data => {
      this.getservicedetails();
    });
    this.dialog.open(EditWashingServiceComponent,dialogconfig);
  }
  onAdd()
  {
    const dialogconfig =  new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus= true;
    this.dialog.afterAllClosed.subscribe(data => {
      this.getservicedetails();
    });
    this.dialog.open(AddWashingServicesComponent,dialogconfig);
  }

  readrole()
  {
    return localStorage.getItem('role');
  }

  onShedule(id)
  {
      localStorage.setItem('servid',id)
      this.route.navigateByUrl('booklocation');
  }

  ondelete(car)
  {
    var r = confirm("confirm delete service!");
    if( r == true)
    {
      this.washser.deleteservice(car).subscribe(data =>
      {
          this.getservicedetails();
      })
      this.curser.afterdelete();
    }
  
  }
}
