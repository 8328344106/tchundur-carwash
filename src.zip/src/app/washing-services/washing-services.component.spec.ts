import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WashingServicesComponent } from './washing-services.component';

describe('WashingServicesComponent', () => {
  let component: WashingServicesComponent;
  let fixture: ComponentFixture<WashingServicesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WashingServicesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WashingServicesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
