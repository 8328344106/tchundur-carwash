import { Injectable } from '@angular/core';
import { HttpClient, HttpEvent, HttpRequest, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Carmodel } from './carmodel';
import { Observable } from 'rxjs';
import { Payment } from './payment';
import { Locations } from './locations';
import { WashService } from './washservice';
import { catchError, tap, map, find } from 'rxjs/operators';
import { Customershedule } from './customershedule';
import { CarouselComponent } from 'ngx-bootstrap/carousel';

@Injectable({
  providedIn: 'root'
})
export class ShedulingServService {

  private CarUrl = 'http://localhost:8888/customercar/car';
  private LocUrl = 'http://localhost:8888/customercar/locations';
  private PaymentUrl = 'http://localhost:8888/customercar/payment';
  private SheduleUrl = 'http://localhost:8888/customercar/shedule';
  constructor(private http: HttpClient) 
  { 

  }

  shedule: Customershedule[];
  getCardetails(): Observable<Carmodel[]>
  {

      return this.http.get<Carmodel[]>(`${this.CarUrl}`+`/getcardetails/`);
  }

  getcarbyuser(): Observable<Carmodel[]>
  {
    const user = localStorage.getItem('username');
    return this.http.get<Carmodel[]>(`${this.CarUrl}`+`/getbyuser/`+`${user}`);
  }

  addfile(id:string,file: File): Observable<any> {
    const formdata: FormData = new FormData();
    formdata.append('file', file);
    return this.http.post(`${this.CarUrl}`+`/addfiledetails/`+`${id}`,formdata);
  }
  addCardetails(car : Carmodel,files: File): Observable<Carmodel>
  {
    const formdata: FormData = new FormData();
    formdata.append('car', JSON.stringify(car));
    formdata.append('file', files);
    return this.http.post<Carmodel>(`${this.CarUrl}`+`/addfiledetails`,formdata);
  }

  getimagefile(id): Observable<any>
  {
    return this.http.get(`${this.CarUrl}`+'/getimage/'+`${id}`);
  }

  getcarbyid(id): Observable<Carmodel>
  {
    return this.http.get<Carmodel>(`${this.CarUrl}`+`/getcarbyid/`+`${id}`);
  }

  deletecar(id): Observable<any>
  {
    return this.http.delete<any>(`${this.CarUrl}`+`/deletecar/`+`${id}`);
  }

  getlocationbyid(id): Observable<Locations>
  {
    return this.http.get<Locations>(`${this.LocUrl}`+`/getlocationbyid/`+`${id}`);
  }

  getalllocation(): Observable<Locations[]>
  {
      return this.http.get<Locations[]>(`${this.LocUrl}`+`/getalllocation`);
  }

  getlocationbyuser(): Observable<Locations[]>
  {
    const user = localStorage.getItem('username');
    return this.http.get<Locations[]>(`${this.LocUrl}`+`/getbyuser/`+`${user}`);
  }

  addlocations(loc: Locations): Observable<Locations>
  {
    return this.http.post<Locations>(`${this.LocUrl}`+`/addlocations`,loc);
  }

  deletelocations(id: string): Observable<any>
  {
    
    return this.http.delete<any>(`${this.LocUrl}`+`/deletelocations/`+`${id}`);
  }

  addpayment(pay): Observable<Payment>
  {
    return this.http.post<Payment>(`${this.PaymentUrl}`+`/addpayment`,pay);
  }

  getallpayment(): Observable<Payment[]>
  {
    return this.http.get<Payment[]>(`${this.PaymentUrl}`+`/getpayment`);
  }
  
  getpaymentbyuser(): Observable<Payment[]>
  {
    const user = localStorage.getItem('username');
    return this.http.get<Payment[]>(`${this.PaymentUrl}`+`/getpaymentbyuser/`+`${user}`);
  }

  getpaymentbyid(id): Observable<Payment>
  {
    return this.http.get<Payment>(`${this.PaymentUrl}`+`/getpaymentbyid/`+`${id}`);
  }
  deletepay(id): Observable<any>
  {
    return this.http.delete<any>(`${this.PaymentUrl}`+`/deletecard/`+`${id}`);
  }

  getallshedule(): Observable<Customershedule[]>
  {
    return this.http.get<Customershedule[]>(`${this.SheduleUrl}`+`/getshedule`);
  }

  getshedbyuser():Observable<Customershedule[]>
  {
    const user = localStorage.getItem('username');
      return this.getallshedule()
      .pipe(
        map((cars: Customershedule[]) => cars.filter(item => item.username == user ))
      );
  }

  getshedwashbyuser():Observable<Customershedule[]>
  {
    const user = localStorage.getItem('username');
    return this.getallshedule()
    .pipe(
      map((shed: Customershedule[]) => shed.filter(items => items.washername == user))
    );
  }

  getshedbyuserandpay():Observable<Customershedule[]>
  {
    return this.getshedbyuser()
    .pipe(
      map((cart: Customershedule[]) => cart.filter(items => items.paymentdetails == null))
    );
  }

  getshedafterorder():Observable<Customershedule[]>
  {
    return this.getshedbyuser()
    .pipe(
      map((order: Customershedule[]) => order.filter(items => items.paymentdetails != null))
    );
  }

  getshedbyid(): Observable<Customershedule>
  {
    const id = localStorage.getItem('shedid');
    return this.getallshedule()
    .pipe(
      map((cars:Customershedule[]) => cars.find(item => item.id == id))
    );
  }

  getshedbyidusingid(): Observable<Customershedule>
  {
    const ids = localStorage.getItem('orderid');
    return this.getallshedule()
    .pipe(
      map((shed: Customershedule[]) => shed.find(item => item.id == ids))
    )
  }

  getshedbybookrequest(): Observable<Customershedule[]>
  {
    return this.getallshedule()
    .pipe(
      map((shed: Customershedule[]) => shed.filter(items => items.status == "booked by user"))
    );
  }

  addshedule(shed: Customershedule): Observable<Customershedule>
  {
    return this.http.post<Customershedule>(`${this.SheduleUrl}`+`/addshedule`,shed);
  }

  deleteshedule(id): Observable<any>
  {
    return this.http.delete<any>(`${this.SheduleUrl}`+`/deleteshedule/`+`${id}`);
  }
}
