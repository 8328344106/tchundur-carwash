import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddWasherDetailsComponent } from './add-washer-details.component';

describe('AddWasherDetailsComponent', () => {
  let component: AddWasherDetailsComponent;
  let fixture: ComponentFixture<AddWasherDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddWasherDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddWasherDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
