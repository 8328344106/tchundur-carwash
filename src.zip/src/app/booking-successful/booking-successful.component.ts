import { Component, OnInit } from '@angular/core';
import { ShedulingServService } from '../sheduling-serv.service';
import { MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Payment } from '../payment';
import { Customershedule } from '../customershedule';
import * as moment from 'moment';

@Component({
  selector: 'app-booking-successful',
  templateUrl: './booking-successful.component.html',
  styleUrls: ['./booking-successful.component.css']
})
export class BookingSuccessfulComponent implements OnInit {

  regForm: FormGroup;
  select;
  check: boolean;
  public todate = new Date();
  payment:Payment=new Payment();
  pay:Payment=new Payment();
  schedule: Customershedule = new Customershedule();
  constructor(private route: Router,
              private fb: FormBuilder,
              private payservice:ShedulingServService) { }

  ngOnInit(): void 
  {
    this.getpaymentbyid();
    this.getscheduelbyid();
    this.regForm = this.fb.group({
      cvv: ['', [Validators.required ]],
    });
  }

  getpaymentbyid()
  {
    const editpayid = localStorage.getItem('payid');
    this.payservice.getpaymentbyid(editpayid).subscribe( data =>
    {
        this.payment = data;
    })
  }

  getscheduelbyid()
  {
    this.payservice.getshedbyid().subscribe( data => {
      if(data != null)
      {
        this.schedule = data;
        if(this.schedule.paymentdetails)
        {
          this.select = "true";
      
        }
        else
        {
          this.select = "false";
        }
      }
      console.log(this.schedule);
    });
  }

  getRandomNumberBetween(min,max)
  {
    return Math.floor(Math.random()*(max-min+1)+min);
  }

  onSubmit()
  {
    if(this.payment.cvv === this.pay.cvv)
    {
        
        this.schedule.paymentdetails = this.payment;
        this.schedule.bookingid = this.getRandomNumberBetween(1000000000,9999999999);
        this.schedule.transactionid = this.getRandomNumberBetween(1000000000,9999999999);
        const momentDate = new Date(this.todate); 
        this.schedule.bookeddate= moment(momentDate).format("DD-MM-YYYY");
        this.schedule.status = "booked by user";
        this.payservice.addshedule(this.schedule).subscribe(data => {
          this.select = "true";
          this.check = false; 
          localStorage.removeItem('payid')
          this.schedule = data;
        })
     
    }
    else
    {
      this.check = true;
      this.select ="false";
      this.pay= new Payment();
    }
  }

  onCancel()
  {
    localStorage.removeItem('shedid');
    localStorage.removeItem('payid');
    this.route.navigateByUrl('home');
  }

  onPrevious()
  {
    this.route.navigateByUrl('selectpayment');
  }

 

}
