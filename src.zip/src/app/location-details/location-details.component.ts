import { Component, OnInit } from '@angular/core';
import { EditCustomerLocationComponent } from '../edit-customer-location/edit-customer-location.component';
import { MatDialogConfig, MatDialog } from '@angular/material/dialog';
import { AddLocationDetailsComponent } from '../add-location-details/add-location-details.component';
import { Router } from '@angular/router';
import { CustomerservService } from '../customerserv.service';
import { Locations } from '../locations';
import { ShedulingServService } from '../sheduling-serv.service';

@Component({
  selector: 'app-location-details',
  templateUrl: './location-details.component.html',
  styleUrls: ['./location-details.component.css']
})
export class LocationDetailsComponent implements OnInit {

  locmodel: Locations[];
  submitted: boolean = false;
  constructor(private route: Router,
              private locser: ShedulingServService,
              private curser: CustomerservService,
              private dialog:MatDialog) { }

  ngOnInit(): void 
  {
      this.getlocationdetails();
  }

 
  getlocationdetails()
  {
    this.locser.getlocationbyuser().subscribe(data =>
      {
        this.locmodel= data as Locations[];
        
      });
  }

  onEdit(editid)
  {

    localStorage.setItem('editlocid',editid);
    const dialogconfig =  new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus= true;
    this.dialog.afterAllClosed.subscribe(data => {
      
      this.getlocationdetails();
    });
    this.dialog.open(EditCustomerLocationComponent,dialogconfig);
  }
  onAdd()
  {
    const dialogconfig =  new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus= true;
    this.dialog.afterAllClosed.subscribe(data => {
      this.getlocationdetails();
    });
    this.dialog.open(AddLocationDetailsComponent,dialogconfig);
  }


  readrole()
  {
    return localStorage.getItem('role');
  }
  ondelete(id)
  {
    console.log(id);
    var r = confirm("Confirm your delete location")
    if(r == true)
    {
    this.locser.deletelocations(id).subscribe(data =>
    {
        this.getlocationdetails();
    })
    this.curser.afterdelete();
  }
  }

}
