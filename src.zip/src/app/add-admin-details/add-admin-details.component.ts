import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-admin-details',
  templateUrl: './add-admin-details.component.html',
  styleUrls: ['./add-admin-details.component.css']
})
export class AddAdminDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
