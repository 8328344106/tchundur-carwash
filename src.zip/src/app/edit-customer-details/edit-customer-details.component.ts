import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Register } from '../register';
import { CustomerservService } from '../customerserv.service';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-edit-customer-details',
  templateUrl: './edit-customer-details.component.html',
  styleUrls: ['./edit-customer-details.component.css']
})
export class EditCustomerDetailsComponent implements OnInit {

  regForm: FormGroup;
  check: boolean = false;
  washer : Register = new Register();
  constructor(private fb: FormBuilder,
              private curser: CustomerservService,
              private dialogref:MatDialogRef<EditCustomerDetailsComponent>) 
  { 
    
  }

  ngOnInit(): void 
  {
    this.curser.getperticularuser().subscribe(res =>
      {
        this.washer = res;
      })

    this.regForm = this.fb.group({

      firstname: ['',Validators.required],

      lastname : ['',Validators.required],

      username: ['', [Validators.required,Validators.maxLength(20),Validators.minLength(3) ]],
  
      email: ['',[ Validators.required,Validators.pattern('[a-zA-Z0-9_.+-]+@gmail.com+$')] ],
      
      mobilenumber: ['',[Validators.required,Validators.minLength(10), Validators.maxLength(10),Validators.pattern('^[6-9]\\d{9}')]],
      
      password:['',[ Validators.required,Validators.maxLength(15),Validators.minLength(6),	Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])[a-zA-Z0-9]+$')] ],

      repeatpassword:['',[ Validators.required,Validators.maxLength(15),Validators.minLength(6),	Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])[a-zA-Z0-9]+$')] ]
    });
  }

  onSave()
  {
      this.curser.addcustomer(this.washer).subscribe(res=>
        {
          if(res != null)
          {
            this.dialogref.close();
          }
          else
          {
            this.check = true;
          }
        })
  }

  onclose()
  {
    this.dialogref.close();
  }

}
