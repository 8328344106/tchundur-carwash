import { Component, OnInit, AfterContentChecked, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { ShedulingServService } from '../sheduling-serv.service';
import { Customershedule } from '../customershedule';
import { NgForm, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CustomerservService } from '../customerserv.service';

@Component({
  selector: 'app-your-orders',
  templateUrl: './your-orders.component.html',
  styleUrls: ['./your-orders.component.css']
})
export class YourOrdersComponent implements OnInit{

  regForm : FormGroup;
  shedule: Customershedule[];
  track : Customershedule;
  rate: boolean;
  rating: Customershedule = new Customershedule();
  check:boolean = false;
  cancel: boolean = false;
  carimage: any;
  serviceimage: any;
  base64Data: any;
  constructor(private route:Router,
              private fb: FormBuilder,
              private curser: CustomerservService,
              private shedser: ShedulingServService) { }

  ngOnInit(): void 
  {
    this.getshedafterorder();
    if(localStorage.getItem('orderid') == null)
    {
      this.check = false;
    }
    else
    {
      this.gettrackbyid();
      this.check = true;
      
    }
    this.regForm = this.fb.group({
      rating: [''],
      review:[''],
    });
  }
 
  getshedafterorder()
  {
    this.shedser.getshedafterorder().subscribe( data => {
      this.shedule = data;       
    })
  }

  gettrackbyid()
  {
    this.shedser.getshedbyidusingid().subscribe( data =>{
        this.track = data;
      this.serviceimage=this.track.servicedetails.image;
      this.base64Data=this.serviceimage;
      this.serviceimage ='data:image/jpeg;Base64,'+this.base64Data;
      this.carimage = this.track.cardetails.image;
      this.base64Data=this.carimage
      this.carimage ='data:image/jpeg;Base64,'+this.base64Data;
      console.log(this.track.status);
      if(this.track.status == "booked by user")
      {
        this.cancel = false;
      }
      else
      {
        this.cancel = true;
      }

      if(this.track.rating == null)
      {
        this.rate = true;
      }
      else
      {
        this.rate = false;
      }
      
    })
  }
  onTrack(id)
  {
    localStorage.setItem('orderid',id);
    this.gettrackbyid();
    this.check = true;
  }

  oncancel()
  {
    var r =confirm("Confirm Cancel the Booked service");
    if(r == true)
    {
      this.track.status = "canceled by user";
      this.shedser.addshedule(this.track).subscribe(data => {
        if(data != null)
        {
           this.cancel = true;
        }
      })
    }
  }

  onSubmit()
  {
    this.track.rating = this.rating.rating;
    this.track.review = this.rating.review;
    this.shedser.addshedule(this.track).subscribe( data => {
      if(data != null)
      {
        this.track = data;
        this.gettrackbyid();
      }
      this.curser.afterdelete();
    })
  }

  readrating()
  {
    if(this.track.rating == null)
    {
      return true;
    }
    else
    {
      return false;
    }
  }
  onclose()
  {
    this.check = false;
    localStorage.removeItem('orderid');
    
  }
}
