import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { FormGroup, Form, FormBuilder, Validators } from '@angular/forms';
import { CustomerservService } from '../customerserv.service';
import { Register } from '../register';
import { ShedulingServService } from '../sheduling-serv.service';
import { Customershedule } from '../customershedule';
import * as moment from 'moment';

@Component({
  selector: 'app-assign-washer',
  templateUrl: './assign-washer.component.html',
  styleUrls: ['./assign-washer.component.css']
})
export class AssignWasherComponent implements OnInit {

  regForm: FormGroup;
  public todate = new Date();
  washer: Register[];
  track: Customershedule = new Customershedule();
  constructor(private cusser: CustomerservService,
              private fb: FormBuilder,
              private shedser: ShedulingServService,
              private dialogref:MatDialogRef<AssignWasherComponent>) { }

  ngOnInit(): void {
    let role ="washer"
    this.cusser.getbyrole(role).subscribe( data => {
      this.washer =  data;
      console.log(this.washer);
    })
    this.regForm = this.fb.group({

      washername: ['', [Validators.required ]],
    })
    this.getperticularshed();
  }

  getperticularshed()
  {
    this.shedser.getshedbyid().subscribe( data =>{
      this.track = data;
    })
  }

  onAssign()
  {
    this.track.status = "accepted";
    this.track.washername = this.regForm.value.washername;
    this.track.washeraccepteddate = moment(this.todate).format("DD-MM-YYYY");
    this.shedser.addshedule(this.track).subscribe( data => {
        if(data != null)
        {
          localStorage.removeItem('shedid');
          this.dialogref.close();
        }
    })
  }

  onclose()
  {
    this.dialogref.close();
  }

}
