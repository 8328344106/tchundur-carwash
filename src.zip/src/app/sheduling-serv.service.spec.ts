import { TestBed } from '@angular/core/testing';

import { ShedulingServService } from './sheduling-serv.service';

describe('ShedulingServService', () => {
  let service: ShedulingServService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ShedulingServService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
