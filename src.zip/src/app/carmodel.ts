export class Carmodel
{
    id: string;
	username: string;
	brand: string;
	color: string;
	cartype: string;
	imagename: string;
    image: string;
}