import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerservService } from '../customerserv.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Register } from '../register';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-customer-login',
  templateUrl: './customer-login.component.html',
  styleUrls: ['./customer-login.component.css']
})
export class CustomerLoginComponent implements OnInit {

  regForm: FormGroup;
  submitted: boolean = false;
  register:Register= new Register();
  login:Register= new Register();
  check: boolean=true;
  constructor(private fb: FormBuilder ,
              private route: Router, 
              private cserv: CustomerservService,
              iconRegistry: MatIconRegistry, 
              sanitizer: DomSanitizer) 
  { 
    iconRegistry.addSvgIcon(
      'account',
      sanitizer.bypassSecurityTrustResourceUrl('assets/account.svg'));
  }

  ngOnInit(): void 
  {
    this.regForm = this.fb.group({
      username: ['', [Validators.required ]],
      password:['',[ Validators.required] ],
    });
  }

  onLogin(user,pass){
    this.submitted=true;
      this.cserv.customerlogin(this.register)
       .subscribe((data) =>{
             (console.log(data),error=>console.error(error));
             if(data!=null){
               this.login = data as Register;
               this.check=true;
               localStorage.setItem('afterlogin',"true");
               localStorage.setItem('role',this.login.role);
               localStorage.setItem('username',user);
               localStorage.setItem('password',pass);
               this.route.navigateByUrl('home');
               
              }
              else
              {
                this.check=false;
              }
             
       })
       
       
    }

}
