import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomercardetailsComponent } from './customercardetails.component';

describe('CustomercardetailsComponent', () => {
  let component: CustomercardetailsComponent;
  let fixture: ComponentFixture<CustomercardetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomercardetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomercardetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
