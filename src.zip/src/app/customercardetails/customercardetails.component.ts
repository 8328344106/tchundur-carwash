import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Carmodel } from '../carmodel';
import { ShedulingServService } from '../sheduling-serv.service';
import {MatDialog, MatDialogConfig} from '@angular/material/dialog';
import { AddCarDetailsComponent } from '../add-car-details/add-car-details.component';
import { CustomerservService } from '../customerserv.service';
import { EditCustomerCarComponent } from '../edit-customer-car/edit-customer-car.component';

@Component({
  selector: 'app-customercardetails',
  templateUrl: './customercardetails.component.html',
  styleUrls: ['./customercardetails.component.css']
})
export class CustomercardetailsComponent implements OnInit {

  regForm: FormGroup;
  base64Data: any;
  carmodel: Carmodel[];
  id:String;
  image:any;
  images:any;
  c : Carmodel;
  constructor(private fb: FormBuilder,
              private route: Router,
              private carshed: ShedulingServService,
              private curser: CustomerservService,
              private dialog:MatDialog) 
  { 

  }

  ngOnInit(): void 
  {
      this.getcarbyuser(); 
  }
  
  getcarbyuser()
  {
    this.carshed.getcarbyuser().subscribe(data=>
      {
        this.carmodel= data as Carmodel[];

        for(let d in this.carmodel)
        {
          //console.log(d);
          this.image=this.carmodel[d];
          this.base64Data=this.image.image;
          this.carmodel[d].image ='data:image/jpeg;Base64,'+this.base64Data;
        }
        
      });
  }
  onAdd()
  {
    const dialogconfig =  new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus= true;
    this.dialog.afterAllClosed.subscribe(data => {
      this.getcarbyuser();
    });
    this.dialog.open(AddCarDetailsComponent,dialogconfig);
  }

  onEdit(car)
  {
    localStorage.setItem('editcarid',car);
    const dialogconfig =  new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus= true;
    this.dialog.afterAllClosed.subscribe(data => {
      this.getcarbyuser();
    });
    this.dialog.open(EditCustomerCarComponent,dialogconfig);
  }
  onDelete(car)
  {
    console.log(car);
    var r = confirm("confrim your car delete!")
    if(r == true)
    {
    this.carshed.deletecar(car).subscribe(data =>
    {
        this.getcarbyuser();
    })
    this.curser.afterdelete();
  }
  }

}
