import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router} from '@angular/Router';
import { MatTableDataSource } from '@angular/material/table';
import { CustomerservService } from '../customerserv.service';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { EditCustomerDetailsComponent } from '../edit-customer-details/edit-customer-details.component';
import { Register } from '../register';

@Component({
  selector: 'app-customer-details',
  templateUrl: './customer-details.component.html',
  styleUrls: ['./customer-details.component.css']
})
export class CustomerDetailsComponent implements OnInit {

  displayedColumns: string[] = ['username','firstname','lastname', 'email', 'mobilenumber','edit','delete'];
  dataSource = new MatTableDataSource();
  role: string;

  model: Register = new Register();
  constructor(private route: Router,
              private active: ActivatedRoute,
              private cusser: CustomerservService,
              private dialog:MatDialog) 
  { 

  }

  ngOnInit(): void 
  {
   
    
    this.getcustomerdetails();
  }
  

  getcustomerdetails()
  {
    this.role="customer";
    this.cusser.getbyrole(this.role).subscribe(res=>
    {
        this.dataSource.data=res;
  
    });
  }
  cus()
  {
    let cus="customer";
    return cus;
  }
  onEdit(element)
  {
    localStorage.setItem('id',element);
    const dialogconfig =  new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus= true;
    this.dialog.afterAllClosed.subscribe(data => {
      this.getcustomerdetails();
    });
    this.dialog.open(EditCustomerDetailsComponent,dialogconfig);
  }

  onDelete(element)
  {
    var r = confirm("Confirm delete customer!")
    if(r == true)
    {
    this.cusser.deleteuser(element).subscribe(
      res =>
      {
        if(res == true)
        {
          this.getcustomerdetails();
        }
      })
      this.cusser.afterdelete(); 
    }
  }

}
