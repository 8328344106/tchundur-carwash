import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { Register } from '../register';
import { Router, ActivatedRoute } from '@angular/router';
import { CustomerservService } from '../customerserv.service';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { EditAdminDetailsComponent } from '../edit-admin-details/edit-admin-details.component';

@Component({
  selector: 'app-admin-details',
  templateUrl: './admin-details.component.html',
  styleUrls: ['./admin-details.component.css']
})
export class AdminDetailsComponent implements OnInit {

  displayedColumns: string[] = ['username','firstname','lastname', 'email', 'mobilenumber','edit','delete'];
  dataSource = new MatTableDataSource();
  role: string;

  model: Register = new Register();
  constructor(private route: Router,
              private active: ActivatedRoute,
              private cusser: CustomerservService,
              private dialog:MatDialog) 
  { 

  }

  ngOnInit(): void 
  {
   
    
    this.getcustomerdetails();
  }
  

  getcustomerdetails()
  {
    this.role="admin";
    this.cusser.getbyrole(this.role).subscribe(res=>
    {
        this.dataSource.data=res;
  
    });
  }
  cus()
  {
    let cus="admin";
    return cus;
  }
  onEdit(element)
  {
    localStorage.setItem('id',element);
    const dialogconfig =  new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus= true;
    this.dialog.afterAllClosed.subscribe(data => {
      this.getcustomerdetails();
    });
    this.dialog.open(EditAdminDetailsComponent,dialogconfig);
  }
  read(user)
  {
    if(localStorage.getItem('username') == user)
    {
      return false;

    }
    else
    {
      return true;
    }
  }

  onDelete(element)
  {
    var r = confirm("Confirm delete customer!")
    if(r == true)
    {
    this.cusser.deleteuser(element).subscribe(
      res =>
      {
        if(res == true)
        {
          this.getcustomerdetails();
        }
      })
      this.cusser.afterdelete(); 
    }
  }

}
