import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Register } from '../register';
import { CustomerservService } from '../customerserv.service'
import { ActivatedRoute, Router} from '@angular/Router';
import { combineAll } from 'rxjs/operators';

@Component({
  selector: 'app-customer-register',
  templateUrl: './customer-register.component.html',
  styleUrls: ['./customer-register.component.css']
})
export class CustomerRegisterComponent implements OnInit {

  regForm: FormGroup;
  check: boolean = false;
  register:Register=new Register();
  constructor(private fb: FormBuilder, 
              private crser: CustomerservService, 
              private active: ActivatedRoute,
              private route :Router) 
  { 

  }

  ngOnInit(): void 
  {
   
    this.regForm = this.fb.group({

      firstname: ['',Validators.required],

      lastname : ['',Validators.required],

      username: ['', [Validators.required,Validators.maxLength(20),Validators.minLength(3) ]],
  
      email: ['',[ Validators.required,Validators.pattern('[a-zA-Z0-9_.+-]+@gmail.com+$')] ],
      
      mobilenumber: ['',[Validators.required,Validators.minLength(10), Validators.maxLength(10),Validators.pattern('^[6-9]\\d{9}')]],
      
      password:['',[ Validators.required,Validators.maxLength(15),Validators.minLength(6),	Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])[a-zA-Z0-9]+$')] ],

      repeatpassword:['',[ Validators.required,Validators.maxLength(15),Validators.minLength(6),	Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])[a-zA-Z0-9]+$')] ]
  });
  }

  onRegister()
  {
    const param = this.active.snapshot.paramMap.get('id');
    // console.log(param);
    this.register.role=param;
    // console.log(this.register); 
    this.crser.addcustomer(this.register)
        .subscribe((data) =>{
            if(data != null)
            {
              // console.log(data),error=>console.error(error);
              if(localStorage.getItem('role') == "admin" && param =="customer")
              {
                this.route.navigateByUrl('cusdetails');
                
              }
              else
              {
                
                if(localStorage.getItem('role') == "admin" && param =="admin")
                {
                  
                  this.route.navigateByUrl('admindetails');
                }
                else
                {
                  this.route.navigateByUrl('login');
                }
              }
            }
            else
            {
              this.check = true;
            }
        });
  }

}
