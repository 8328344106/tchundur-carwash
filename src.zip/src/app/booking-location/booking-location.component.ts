import { Component, OnInit } from '@angular/core';
import { EditCustomerLocationComponent } from '../edit-customer-location/edit-customer-location.component';
import { MatDialogConfig, MatDialog } from '@angular/material/dialog';
import { Locations } from '../locations';
import { Router } from '@angular/router';
import { ShedulingServService } from '../sheduling-serv.service';
import { CustomerservService } from '../customerserv.service';
import { AddLocationDetailsComponent } from '../add-location-details/add-location-details.component';

@Component({
  selector: 'app-booking-location',
  templateUrl: './booking-location.component.html',
  styleUrls: ['./booking-location.component.css']
})
export class BookingLocationComponent implements OnInit {

  locmodel: Locations[];
  select= "false";
  id: string;
  submitted: boolean = false;
  constructor(private route: Router,
              private locser: ShedulingServService,
              private curser: CustomerservService,
              private dialog:MatDialog) { }

  ngOnInit(): void 
  {
      this.getlocationdetails();
      this.getselect();
      
  }
  getselect()
  {
      if(localStorage.getItem('locid') == null)
      {
          console.log(this.select);
      }
      else
      {
        this.id = localStorage.getItem('locid');
        this.select="true";
      }
  }
  onselect(loc)
  {
    this.id = loc.id;
    localStorage.setItem('locid',loc.id);
    this.select = "true";
  }

  onPrevious()
  {
    this.route.navigateByUrl('ser');
  }

  onNext()
  {
    this.route.navigateByUrl('bookcar');
  }
  getlocationdetails()
  {
    this.locser.getlocationbyuser().subscribe(data =>
      {
        this.locmodel= data as Locations[];
        
      });
  }

  onEdit(editid)
  {

    localStorage.setItem('editlocid',editid);
    const dialogconfig =  new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus= true;
    this.dialog.afterAllClosed.subscribe(data => {
      
      this.getlocationdetails();
    });
    this.dialog.open(EditCustomerLocationComponent,dialogconfig);
  }
  onAdd()
  {
    const dialogconfig =  new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus= true;
    this.dialog.afterAllClosed.subscribe(data => {
      this.getlocationdetails();
    });
    this.dialog.open(AddLocationDetailsComponent,dialogconfig);
  }

  readrole()
  {
    return localStorage.getItem('role');
  }

  onCancel()
  {
    localStorage.removeItem('servid');
    localStorage.removeItem('locid');
    localStorage.removeItem('carid');
    this.route.navigateByUrl('home');
  }
  ondelete(locat)
  {
    var r =confirm("confirm delete your location!")
    if(r == true)
    {
      if(this.id == locat)
      {
        localStorage.removeItem('locid');
        this.id = null;
        this.select = "false";
       
        
      }
      this.locser.deletelocations(locat).subscribe(data =>
      {
          this.getlocationdetails();
          this.getselect();
      })
      this.curser.afterdelete();
    }
  }

}

