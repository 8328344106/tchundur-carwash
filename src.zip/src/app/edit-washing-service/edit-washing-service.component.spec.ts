import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditWashingServiceComponent } from './edit-washing-service.component';

describe('EditWashingServiceComponent', () => {
  let component: EditWashingServiceComponent;
  let fixture: ComponentFixture<EditWashingServiceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditWashingServiceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditWashingServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
