import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { WashService } from '../washservice';
import { Router } from '@angular/router';
import { AdminSerService } from '../admin-ser.service';

@Component({
  selector: 'app-edit-washing-service',
  templateUrl: './edit-washing-service.component.html',
  styleUrls: ['./edit-washing-service.component.css']
})
export class EditWashingServiceComponent implements OnInit {

  regForm: FormGroup;
  submitted: boolean = false;
  servmodel: WashService=new WashService();
  constructor(private fb: FormBuilder,
              private route: Router,
              private admser: AdminSerService,
              private dialogref:MatDialogRef<EditWashingServiceComponent>) { }

  ngOnInit(): void 
  {
    this.getpackagebyid();
    this.regForm = this.fb.group({
      servicename: ['', [Validators.required ]],
      description:['',[ Validators.required] ],
      amount:['',[ Validators.required] ],
      imagefile:['',[ Validators.required] ]
    });
  }

  getpackagebyid()
  {
      this.admser.getperticularservice().subscribe( data =>{
        this.servmodel = data;
      })
  }

  selectedFiles: FileList;
  currentFileUpload: File;
  onSelectFile(event)
  {
    this.selectedFiles = event.target.files;
  }
  onAdd()
  {
    this.currentFileUpload = this.selectedFiles.item(0);
    this.admser.addServdetails(this.servmodel,this.currentFileUpload)
    .subscribe((data) =>
    {
      this.dialogref.close();
      
    })

  }
onclose()
{
  localStorage.removeItem('servid');
  this.dialogref.close();
}

}
