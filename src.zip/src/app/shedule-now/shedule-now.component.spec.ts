import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SheduleNowComponent } from './shedule-now.component';

describe('SheduleNowComponent', () => {
  let component: SheduleNowComponent;
  let fixture: ComponentFixture<SheduleNowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SheduleNowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SheduleNowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
