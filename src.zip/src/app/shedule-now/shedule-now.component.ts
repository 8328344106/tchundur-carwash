import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { WashService } from '../washservice';
import { AdminSerService } from '../admin-ser.service';
import { ShedulingServService } from '../sheduling-serv.service';
import { Carmodel } from '../carmodel';
import { Router } from '@angular/router';
import { Locations } from '../locations';
import { Customershedule } from '../customershedule';
import * as moment from 'moment';

@Component({
  selector: 'app-shedule-now',
  templateUrl: './shedule-now.component.html',
  styleUrls: ['./shedule-now.component.css']
})
export class SheduleNowComponent implements OnInit {

  regForm: FormGroup;
  public todate = new Date();
  base64Data: any;
  checked = false;
  image:any;
  serviceimage:any;
  carimage:any;
  servicemodel : WashService = new WashService();
  carmodel : Carmodel = new Carmodel();
  locmodel : Locations = new Locations();
  shedulemodel : Customershedule = new Customershedule(); 
  
  constructor(private fb: FormBuilder,
              private washserv: AdminSerService,
              private route: Router,
              private shedserv: ShedulingServService) 
  { }

  ngOnInit(): void 
  {
    this.regForm = this.fb.group({
      sheduledate: ['',[Validators.required]],
      sheduletime: ['',[Validators.required]],
      checked: ['', [Validators.required]]

    });
    this.getperticularservice();
    this.getperticularcar();
    this.getperticularlocation();
  }

  getperticularservice()
  {
    this.washserv.getperticularservice().subscribe( data =>
      {
          this.servicemodel = data as WashService;
          this.image=this.servicemodel;
          this.base64Data=this.image.image;
          this.serviceimage ='data:image/jpeg;Base64,'+this.base64Data;
      });
  }

  getperticularcar()
  {
      this.shedserv.getcarbyid(localStorage.getItem('carid')).subscribe( data =>
        {
          this.carmodel = data as Carmodel;
          this.image=this.carmodel;
          this.base64Data=this.image.image;
          this.carimage ='data:image/jpeg;Base64,'+this.base64Data;
        })
  }

  getperticularlocation()
  {
    this.shedserv.getlocationbyid(localStorage.getItem('locid')).subscribe( data =>
      {
        this.locmodel = data as Locations;
        
      })
  }

  totalAmount()
  {
    this.shedulemodel.totalamount = ((this.serviceTax())+ this.servicemodel.amount);
    return this.shedulemodel.totalamount;
  }

  serviceTax()
  {
    this.shedulemodel.servicetax = ((this.servicemodel.amount) * 10) / 100;
    return this.shedulemodel.servicetax;
  }

  onConfirm()
  {
    this.shedulemodel.username = localStorage.getItem('username');
    const momentDate = new Date(this.shedulemodel.sheduledate); 
    this.shedulemodel.sheduledate= moment(momentDate).format("DD-MM-YYYY");
    this.shedulemodel.servicedetails = this.servicemodel;
    this.shedulemodel.cardetails = this.carmodel;
    this.shedulemodel.locationdetails = this.locmodel;
    this.shedserv.addshedule(this.shedulemodel).subscribe(data =>
      {
        if(data != null)
        {
          localStorage.removeItem('servid');
          localStorage.removeItem('locid');
          localStorage.removeItem('carid');
          this.route.navigateByUrl('cart');
        }
      })  
  }

  onPrevious()
  {
    this.route.navigateByUrl('bookcar');
  }

  onCancel()
  {
    localStorage.removeItem('servid');
    localStorage.removeItem('locid');
    localStorage.removeItem('carid');
    this.route.navigateByUrl('home');
  }


}
