import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HeaderNavComponent } from './header-nav/header-nav.component';
import { CustomerRegisterComponent } from './customer-register/customer-register.component';
import { CustomerLoginComponent } from './customer-login/customer-login.component';
import { HomeComponent } from './home/home.component';
import { CustomercardetailsComponent } from './customercardetails/customercardetails.component';
import { CustomerPaymentDetailsComponent } from './customer-payment-details/customer-payment-details.component';
import { AddCarDetailsComponent } from './add-car-details/add-car-details.component';
import { WasherHistoryComponent } from './washer-history/washer-history.component';
import { SheduleNowComponent } from './shedule-now/shedule-now.component';
import { AddPaymentDetailsComponent } from './add-payment-details/add-payment-details.component';
import { WashingServicesComponent } from './washing-services/washing-services.component';
import { WasherDetailsComponent } from './washer-details/washer-details.component';
import { EditWasherDetailsComponent } from './edit-washer-details/edit-washer-details.component';
import { CustomerDetailsComponent } from './customer-details/customer-details.component';
import { EditCustomerDetailsComponent } from './edit-customer-details/edit-customer-details.component';
import { EditWashingServiceComponent } from './edit-washing-service/edit-washing-service.component';
import { LocationDetailsComponent } from './location-details/location-details.component';
import { AddLocationDetailsComponent } from './add-location-details/add-location-details.component';
import { BookingCarComponent } from './booking-car/booking-car.component';
import { BookingLocationComponent } from './booking-location/booking-location.component';
import { SelectPaymentComponent } from './select-payment/select-payment.component';
import { BookingSuccessfulComponent } from './booking-successful/booking-successful.component';
import { CartComponent } from './cart/cart.component';
import { YourOrdersComponent } from './your-orders/your-orders.component';
import { AdminDetailsComponent } from './admin-details/admin-details.component';
import { CustomerWashRequestsComponent } from './customer-wash-requests/customer-wash-requests.component';

const routes: Routes = [
  { path: 'nnav', component: HeaderNavComponent },
  { path: 'home', component: HomeComponent },
  { path: 'ser', component: WashingServicesComponent},
  { path: 'editser', component: EditWashingServiceComponent},
  { path: 'cusregister/:id', component: CustomerRegisterComponent },
  { path: 'login', component: CustomerLoginComponent },
  { path: 'cardetails', component: CustomercardetailsComponent},
  { path: 'addcardetails', component: AddCarDetailsComponent},
  { path: 'bookcar',component: BookingCarComponent},
  { path: 'locations', component: LocationDetailsComponent},
  { path: 'addlocation', component: AddLocationDetailsComponent},
  { path: 'booklocation',component:BookingLocationComponent},
  { path: 'payment', component: CustomerPaymentDetailsComponent},
  { path: 'selectpayment', component: SelectPaymentComponent},
  { path: 'addpayment', component: AddPaymentDetailsComponent},
  { path: 'shedulenow', component: SheduleNowComponent},
  { path: 'cart',component:CartComponent},
  { path: 'success',component: BookingSuccessfulComponent},
  { path: 'customerhistory',component: YourOrdersComponent},
  { path: 'cusdetails', component: CustomerDetailsComponent},
  { path: 'admindetails',component: AdminDetailsComponent},
  { path: 'editcus', component: EditCustomerDetailsComponent},
  { path: 'washer', component: WasherDetailsComponent},
  { path: 'editwasher', component: EditWasherDetailsComponent},
  { path: 'bookingrequests',component:CustomerWashRequestsComponent},
  { path: 'washhistory', component: WasherHistoryComponent},
  { path: '**', redirectTo:'home' }
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
