import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditCustomerPaymentComponent } from './edit-customer-payment.component';

describe('EditCustomerPaymentComponent', () => {
  let component: EditCustomerPaymentComponent;
  let fixture: ComponentFixture<EditCustomerPaymentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditCustomerPaymentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditCustomerPaymentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
