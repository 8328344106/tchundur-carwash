import { Component, OnInit } from '@angular/core';
import { Payment } from '../payment';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ShedulingServService } from '../sheduling-serv.service';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-edit-customer-payment',
  templateUrl: './edit-customer-payment.component.html',
  styleUrls: ['./edit-customer-payment.component.css']
})
export class EditCustomerPaymentComponent implements OnInit {

  regForm: FormGroup;

  payment:Payment=new Payment();
  constructor(private fb: FormBuilder, 
              private payservice:ShedulingServService,
              private dialogref:MatDialogRef<EditCustomerPaymentComponent>) 
  { 

  }

  ngOnInit() 
  {
    this.getpaymentbyid();
    this.regForm = this.fb.group({
      cardnumber: ['', [Validators.required]],
      expmon:['',[ Validators.required] ],
      expyear:['',[Validators.required] ],
      cvv: ['', [Validators.required ]],
      cardholdername:['',[ Validators.required] ]
    });
  }
  
  getpaymentbyid()
  {
    const editpayid = localStorage.getItem('editpayid');
    this.payservice.getpaymentbyid(editpayid).subscribe( data =>
      {
        this.payment = data;
      })
  }
  onPayment(){
    this.payment.username=localStorage.getItem('username');
    this.payservice.addpayment(this.payment)
    .subscribe((data ) => {
      this.dialogref.close();
    });
    

  }

  onclose(){
    localStorage.removeItem('editpayid');
    this.dialogref.close();
  }

}

