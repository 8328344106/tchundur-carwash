import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerWashRequestsComponent } from './customer-wash-requests.component';

describe('CustomerWashRequestsComponent', () => {
  let component: CustomerWashRequestsComponent;
  let fixture: ComponentFixture<CustomerWashRequestsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerWashRequestsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerWashRequestsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
