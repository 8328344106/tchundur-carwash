import { Component, OnInit } from '@angular/core';
import { Payment } from '../payment'
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ShedulingServService } from '../sheduling-serv.service';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-add-payment-details',
  templateUrl: './add-payment-details.component.html',
  styleUrls: ['./add-payment-details.component.css']
})
export class AddPaymentDetailsComponent implements OnInit {

  regForm: FormGroup;

  payment:Payment=new Payment();
  constructor(private fb: FormBuilder, 
              private route: Router,
              private payservice:ShedulingServService,
              private dialogref:MatDialogRef<AddPaymentDetailsComponent>) 
  { 

  }

  ngOnInit() {
    this.regForm = this.fb.group({
      cardnumber: ['', [Validators.required]],
      expmon:['',[ Validators.required] ],
      expyear:['',[Validators.required] ],
      cvv: ['', [Validators.required ]],
      cardholdername:['',[ Validators.required] ]
    });
  }
  

  onPayment(){
    this.payment.username=localStorage.getItem('username');
    this.payservice.addpayment(this.payment)
    .subscribe((data ) => {
      this.dialogref.close();
    });
    

  }

  onclose(){
    this.dialogref.close();
  }

}
