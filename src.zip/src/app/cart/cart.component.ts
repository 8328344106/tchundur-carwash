import {
  Component,
  OnInit
} from '@angular/core';
import {
  MatTableDataSource
} from '@angular/material/table';
import {
  ShedulingServService
} from '../sheduling-serv.service';
import {
  Customershedule
} from '../customershedule';
import { CustomerservService } from '../customerserv.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  displayedColumns: string[] = ['servicedetails', 'cardetails', 'locationdetails', 'time', 'payment', 'delete'];
  dataSource = new MatTableDataSource();
  image: any;
  base64Data: any;
  schedule : Customershedule[];
  constructor(private payservice: ShedulingServService,
              private route: Router,
              private cusser: CustomerservService) {}

  ngOnInit(): void {
    this.getshedulebyuser();
  }

  getshedulebyuser() {
   this.payservice.getshedbyuserandpay().subscribe(data =>{
     if(data != null)
     {
      for (let d in data) {
      //console.log(d);
      this.image = data[d].cardetails;
      this.base64Data = this.image.image;
      data[d].cardetails.image = 'data:image/jpeg;Base64,' + this.base64Data;
      }
     this.dataSource.data = data;
    }
   })
    
  }

  onPayment(id)
  {
    localStorage.setItem('shedid',id);
    this.route.navigateByUrl('selectpayment');
  }

  onDelete(id)
  {
      var r=confirm("confirm your delete the cart item!")
      if(r == true)
      {
        this.payservice.deleteshedule(id).subscribe(data =>
          {
            this.getshedulebyuser();
          })
      }
      this.cusser.afterdelete();
  }
}
